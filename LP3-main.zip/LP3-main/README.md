# LP3
This is an academic purpose repository.
https://pickle-shop-9e8.notion.site/LP3-c75ca93e1a4d4a83aed9787b0ca237da?pvs=4
# Any unethical practices is not the responsibility of repository owner. 
